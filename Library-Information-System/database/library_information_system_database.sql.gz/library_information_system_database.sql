-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2024 at 10:19 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_information_system_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_credentials`
--

CREATE TABLE `admin_credentials` (
  `admin_id` int(11) NOT NULL,
  `admin_username` varchar(50) NOT NULL,
  `admin_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_credentials`
--

INSERT INTO `admin_credentials` (`admin_id`, `admin_username`, `admin_password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(11) NOT NULL,
  `call_number` varchar(50) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `isbn` varchar(100) DEFAULT NULL,
  `publisher` varchar(100) DEFAULT NULL,
  `published` date DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `call_number`, `title`, `category`, `author`, `isbn`, `publisher`, `published`, `quantity`) VALUES
(40, 'QA76.754', 'Agile Software Development', 'Software Development', 'Robert C. Martin', '9780135974445', 'Prentice Hall', '2002-04-11', 3),
(41, 'QA76.9.D343', 'Python for Data Analysis', 'Data Science', 'Wes McKinney', '9781491957660', 'O\'Reilly Media', '2017-10-20', 4),
(42, 'Q335', 'Artificial Intelligence: A Modern Approach', 'Artificial Intelligence (AI)', 'Stuart Russell', '9780134610993', 'Pearson', '2020-06-03', 6),
(43, 'QA76.9.A25', 'Cryptography and Network Security', 'Cybersecurity', 'William Stallings', '9780134444284', 'Pearson', '2016-01-20', 2),
(44, 'TK5105.5', 'Computer Networking: A Top-Down Approach', 'Networking', 'James F. Kurose', '9780133594140', 'Pearson', '2017-04-10', 5);

-- --------------------------------------------------------

--
-- Table structure for table `borrowed`
--

CREATE TABLE `borrowed` (
  `borrowed_id` int(11) NOT NULL,
  `usn` int(11) DEFAULT NULL,
  `section` char(10) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phonenumber` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `borrowed_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `isbn` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrowed`
--

INSERT INTO `borrowed` (`borrowed_id`, `usn`, `section`, `name`, `phonenumber`, `address`, `borrowed_date`, `due_date`, `title`, `isbn`, `status`) VALUES
(2040, 1010, 'CS22A', 'Matt', 9123, 'Mparang', '2024-05-21', '2024-05-28', 'Agile Software Development', '9780135974445', 'Borrowing'),
(2041, 1010, 'CS22A', 'Matt', 9123, 'MParang', '2024-05-21', '2024-05-28', 'Python for Data Analysis', '9781491957660', 'Borrowing'),
(2042, 1010, 'CS22A', 'Matt', 9123, 'MParang', '2024-04-21', '2024-04-28', 'Artificial Intelligence: A Modern Approach', '9780134610993', 'Borrowing'),
(2043, 1010, 'CS22A', 'Matt', 9123, 'MParang', '2024-06-21', '2024-06-28', 'Cryptography and Network Security', '9780134444284', 'Borrowing'),
(2044, 1010, 'CS22A', 'Matt', 9123, 'MParang', '2024-06-21', '2024-06-28', 'Computer Networking: A Top-Down Approach', '9780133594140', 'Borrowing'),
(2045, 2020, 'CS31A', 'Steven', 9321, 'StevenHouse', '2024-06-21', '2024-06-28', 'Agile Software Development', '9780135974445', 'Borrowing'),
(2046, 2020, 'CS31A', 'Steven', 9321, 'StevenHouse', '2024-06-21', '2024-06-28', 'Python for Data Analysis', '9781491957660', 'Borrowing');

-- --------------------------------------------------------

--
-- Table structure for table `user_credentials`
--

CREATE TABLE `user_credentials` (
  `user_id` int(11) NOT NULL,
  `user_usn` int(11) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_section` varchar(100) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_credentials`
--

INSERT INTO `user_credentials` (`user_id`, `user_usn`, `user_password`, `user_section`, `user_name`) VALUES
(11, 1010, 'user1010', 'CS22A', 'Matt'),
(12, 2020, 'user2020', 'CS31A', 'Steven');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_credentials`
--
ALTER TABLE `admin_credentials`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `borrowed`
--
ALTER TABLE `borrowed`
  ADD PRIMARY KEY (`borrowed_id`);

--
-- Indexes for table `user_credentials`
--
ALTER TABLE `user_credentials`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `borrowed`
--
ALTER TABLE `borrowed`
  MODIFY `borrowed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2047;

--
-- AUTO_INCREMENT for table `user_credentials`
--
ALTER TABLE `user_credentials`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
